/**
 * Common components exports
 */

export { ResizeHandle, type ResizeHandleProps } from './ResizeHandle';