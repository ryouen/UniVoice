// アプリケーションをリロードしてテストを実行
console.log('🔄 アプリケーションをリロードします...');
window.location.reload();