/**
 * Presentation hooks exports
 */

export { useResize, type UseResizeOptions, type UseResizeReturn } from './useResize';