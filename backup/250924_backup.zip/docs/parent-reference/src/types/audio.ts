export interface AudioResult {
  text: string;
  timestamp: number;
} 