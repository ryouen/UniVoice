import React from 'react';
import { UniVoicePerfectIntegration } from './components/UniVoicePerfectIntegration';
import './index.css';

function App() {
  // UniVoicePerfectIntegration（Phase統合版）を表示
  return <UniVoicePerfectIntegration />;
}

export default App;
