/**
 * Services barrel export
 */

export { WindowClient, windowClient } from './WindowClient';