// アプリケーションをリロード
if (window.location) {
  console.log('🔄 アプリケーションをリロードします...');
  window.location.reload();
}