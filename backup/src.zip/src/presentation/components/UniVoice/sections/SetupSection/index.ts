/**
 * SetupSection exports
 */

export { SetupSection, type SetupSectionProps } from './SetupSection';
